package snake;

import javax.swing.ImageIcon;
import java.awt.Image;

public class Obstacles extends Sprite {
    public Obstacles(int x, int y, int width, int height) {
        super(x, y, width, height, loadImage());
    }

    private static Image loadImage() {
        // Attempt to load the wall image
        try {
            ImageIcon icon = new ImageIcon(Obstacles.class.getResource("/wall.jpg"));
            return icon.getImage();
        } catch (Exception e) {
            System.err.println("Error: Could not load wall.jpg");
            return new ImageIcon().getImage(); // Return a placeholder image
        }
    }
}
