package snake;

public class Main {
    public static void main(String[] args) {
        new SnakeGameGUI(); // Initialize the GUI and start the game
    }
}
