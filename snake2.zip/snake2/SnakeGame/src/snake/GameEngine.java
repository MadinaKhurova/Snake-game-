package snake;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.*;

public class GameEngine extends JPanel {
    private Snake snake;
    private Apple apple;
    private List<Obstacles> obstacles; // Obstacles in the game
    private Timer timer;
    private boolean gameOver = false;
    private Player player;
    private static final String SCORE_FILE = "high_scores.txt";
    private JButton restartButton, highScoresButton;

    public GameEngine() {
        String[] levels = {"Easy", "Medium", "Hard"};
        String level = (String) JOptionPane.showInputDialog(
                null,
                "Choose a difficulty level:",
                "Select Level",
                JOptionPane.PLAIN_MESSAGE,
                null,
                levels,
                "Medium"
        );

        int delay = 100; // Default for Medium
        if ("Easy".equals(level)) {
            delay = 150; // Slower snake
        } else if ("Hard".equals(level)) {
            delay = 70; // Faster snake
        }

        String playerName = JOptionPane.showInputDialog(null, "Enter your name:", "Snake Game", JOptionPane.PLAIN_MESSAGE);
        if (playerName == null || playerName.trim().isEmpty()) {
            playerName = "Guest";
        }
        player = new Player(playerName);
        snake = new Snake(400, 300); // Initialize the Snake object
        obstacles = new ArrayList<>(); // Initialize the obstacles list
        obstacles = generateObstacles(); // Generate obstacles
        spawnApple(); // Generate the first apple

        setLayout(null); // Use absolute positioning for buttons

        // Add Restart Button
        restartButton = new JButton("Reset");
        restartButton.setBounds(700, 10, 90, 30); // Position the button on the panel
        restartButton.addActionListener(e -> restartGame());
        add(restartButton); // Add the button to the panel

        // Add High Scores Button
        highScoresButton = new JButton("High Scores");
        highScoresButton.setBounds(700, 50, 90, 30); // Position the button on the panel
        highScoresButton.addActionListener(e -> showHighScores());
        add(highScoresButton); // Add the button to the panel

        setFocusable(true); // Make the JPanel focusable to receive key events
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                switch (key) {
                    case KeyEvent.VK_W -> snake.setDirection(0, -1); // Move up
                    case KeyEvent.VK_S -> snake.setDirection(0, 1);  // Move down
                    case KeyEvent.VK_A -> snake.setDirection(-1, 0); // Move left
                    case KeyEvent.VK_D -> snake.setDirection(1, 0);  // Move right
                }
            }
        });

        timer = new Timer(delay, e -> gameLoop()); // Timer with dynamic delay based on level
        timer.start(); // Start the timer
    }

    private void spawnApple() {
        Random rand = new Random();
        int x, y;
        int attempts = 0; // Limit attempts to avoid infinite loops
        do {
            x = rand.nextInt(39) * 20; // Random x-coordinate
            y = rand.nextInt(29) * 20; // Random y-coordinate
            attempts++;
        } while (isOccupied(x, y) && attempts < 100); // Ensure apple doesn't spawn on obstacles or the snake

        if (attempts < 100) {
            apple = new Apple(x, y, 20); // Create the apple
        } else {
            System.err.println("Error: Could not spawn apple.");
        }
    }

    private List<Obstacles> generateObstacles() {
        List<Obstacles> obsList = new ArrayList<>();
        Random rand = new Random();
        int attempts = 0;

        for (int i = 0; i < 10; i++) { // Generate 10 random obstacles
            int x, y;
            do {
                x = rand.nextInt(39) * 20;
                y = rand.nextInt(29) * 20;
                attempts++;
            } while (isOccupied(x, y) && attempts < 100); // Avoid overlapping obstacles

            if (attempts < 100) {
                obsList.add(new Obstacles(x, y, 20, 20));
            } else {
                System.err.println("Error: Could not place all obstacles.");
                break;
            }
        }
        return obsList;
    }

    private boolean isOccupied(int x, int y) {
        // Check if the position is occupied by an obstacle
        for (Obstacles obs : obstacles) {
            if (obs.getX() == x && obs.getY() == y) return true;
        }
        // Check if the position is occupied by the snake
        return snake.getBody().stream().anyMatch(point -> point.x == x && point.y == y);
    }

    private void gameLoop() {
        if (gameOver) return;

        snake.move(); // Move the snake

        // Check if the snake eats the apple
        if (snake.collidesWith(new Point(apple.getX(), apple.getY()))) {
            snake.grow(); // Increase the snake size
            player.incrementScore(10);
            spawnApple(); // Generate a new apple
        }

        // Check for collisions
        if (checkCollision()) {
            gameOver = true;
            timer.stop();
            saveHighScore();
            JOptionPane.showMessageDialog(this, "Game Over! Your Score: " + player.getScore());
        }

        repaint(); // Redraw the game screen
    }

    private boolean checkCollision() {
        Point head = snake.getBody().getFirst();
        // Check for boundary, self-collision, or collision with obstacles
        return head.x < 0 || head.x >= 800 || head.y < 0 || head.y >= 600 ||
                snake.collidesWithSelf() ||
                obstacles.stream().anyMatch(obs -> obs.getBounds().contains(head.x, head.y));
    }

    private void saveHighScore() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SCORE_FILE, true))) {
            writer.write(player.getName() + ":" + player.getScore());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error: Could not save high score.");
        }
    }

    private void showHighScores() {
        List<String> scores = loadHighScores();
        scores.sort((a, b) -> {
            int scoreA = Integer.parseInt(a.split(":")[1]);
            int scoreB = Integer.parseInt(b.split(":")[1]);
            return Integer.compare(scoreB, scoreA); // Sort in descending order
        });

        StringBuilder scoreDisplay = new StringBuilder("Top 10 Players:\n");
        for (int i = 0; i < Math.min(scores.size(), 10); i++) {
            scoreDisplay.append(i + 1).append(". ").append(scores.get(i)).append("\n");
        }

        JOptionPane.showMessageDialog(this, scoreDisplay.toString(), "High Scores", JOptionPane.INFORMATION_MESSAGE);
    }

    private List<String> loadHighScores() {
        List<String> scores = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(SCORE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                scores.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error: Could not load high scores.");
        }
        return scores;
    }

    private void restartGame() {
        gameOver = false; // Reset the game over flag
        player.resetScore(); // Reset the player's score
        snake = new Snake(400, 300); // Reset the snake
        obstacles = generateObstacles(); // Regenerate obstacles
        spawnApple(); // Spawn a new apple
        timer.restart(); // Restart the game timer

        // Re-register the key listener to ensure it works with the new snake
        removeKeyListener(getKeyListeners()[0]); // Remove any existing KeyListener
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                switch (key) {
                    case KeyEvent.VK_W -> snake.setDirection(0, -1); // Move up
                    case KeyEvent.VK_S -> snake.setDirection(0, 1);  // Move down
                    case KeyEvent.VK_A -> snake.setDirection(-1, 0); // Move left
                    case KeyEvent.VK_D -> snake.setDirection(1, 0);  // Move right
                }
            }
        });

        setFocusable(true); // Make the JPanel focusable to receive key events
        requestFocusInWindow(); // Ensure the panel has focus for key inputs
        repaint(); // Refresh the screen
    }



    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        snake.draw(g); // Draw the snake
        apple.draw(g); // Draw the apple
        for (Obstacles obs : obstacles) {
            obs.draw(g); // Draw the obstacles
        }
        g.setColor(Color.BLACK);
        g.drawString("Player: " + player.getName(), 10, 20);
        g.drawString("Score: " + player.getScore(), 10, 40);
    }
}
