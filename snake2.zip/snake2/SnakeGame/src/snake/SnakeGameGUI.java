package snake;

import javax.swing.*;
import java.awt.*;

public class SnakeGameGUI {
    private JFrame frame;
    private GameEngine gameEngine;

    public SnakeGameGUI() {
        frame = new JFrame("Snake Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        gameEngine = new GameEngine();
        frame.getContentPane().add(gameEngine);

        frame.setPreferredSize(new Dimension(800, 600));
        frame.setResizable(false);
        frame.pack();
        frame.setVisible(true);
    }
}
