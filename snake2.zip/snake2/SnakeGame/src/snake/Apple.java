package snake;

import javax.swing.ImageIcon;
import java.awt.Image;

public class Apple extends Sprite {
    public Apple(int x, int y, int size) {
        super(x, y, size, size, loadImage());
    }

    private static Image loadImage() {
        // Attempt to load the apple image
        try {
            ImageIcon icon = new ImageIcon(Apple.class.getResource("/apple.jpg"));
            return icon.getImage();
        } catch (Exception e) {
            System.err.println("Error: Could not load apple.jpg");
            return new ImageIcon().getImage(); // Return a placeholder image
        }
    }
}
