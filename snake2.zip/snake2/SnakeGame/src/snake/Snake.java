package snake;

import java.awt.*;
import java.util.LinkedList;

public class Snake {
    private LinkedList<Point> body; // Each part of the snake's body
    private int directionX = 1, directionY = 0; // Initial direction (right)

    public Snake(int startX, int startY) {
        body = new LinkedList<>();
        body.add(new Point(startX, startY));
        body.add(new Point(startX - 20, startY)); // Two units long initially
    }

    public void move() {
        Point head = body.getFirst();
        Point newHead = new Point(head.x + directionX * 20, head.y + directionY * 20);

        body.addFirst(newHead); // Add new head
        body.removeLast(); // Remove tail
    }

    public void grow() {
        body.addLast(new Point(body.getLast().x, body.getLast().y));
    }

    public boolean collidesWith(Point p) {
        return body.contains(p);
    }

    public boolean collidesWithSelf() {
        Point head = body.getFirst();
        return body.stream().skip(1).anyMatch(segment -> segment.equals(head));
    }

    public void setDirection(int dx, int dy) {
        // Prevent the snake from reversing
        if (dx != -directionX && dy != -directionY) {
            directionX = dx;
            directionY = dy;
        }
    }

    public LinkedList<Point> getBody() {
        return body;
    }

    public void draw(Graphics g) {
        g.setColor(Color.GREEN); // Set snake color
        for (Point p : body) {
            g.fillRect(p.x, p.y, 20, 20); // Each segment is a 20x20 square
        }
    }
}
